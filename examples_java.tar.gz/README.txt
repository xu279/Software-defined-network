To build the server:
1. To compile the server code : javac EchoServer.java
-- Three classes are generated -- EchoServer.class, ClientEchoHandler.class, MyTimerTask.class
2. To create a server JAR file 
jar cvfm EchoServer.jar manifest.txt EchoServer.class ClientEchoHandler.class MyTimerTask.class

To build the client:
1. javac EchoClient.java

To run the server and client:
1. java -cp EchoServer.jar EchoServer
2. java EchoClient
